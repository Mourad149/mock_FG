<!DOCTYPE>
<html lang="ar">
  
<head>
<meta name="facebook-domain-verification" content="c4jkx5tku5f54aj8f8jzknwamgdqvw" />
  <!-- Hotjar Tracking Code for https://landingpage.thalya.ma -->
<script>
    (function(h,o,t,j,a,r){
        h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};
        h._hjSettings={hjid:2702353,hjsv:6};
        a=o.getElementsByTagName('head')[0];
        r=o.createElement('script');r.async=1;
        r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;
        a.appendChild(r);
    })(window,document,'https://static.hotjar.com/c/hotjar-','.js?sv=');
</script>
  <!-- Facebook Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '174008244912245');
fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=174008244912245&ev=PageView&noscript=1"
/></noscript>
<!-- End Facebook Pixel Code -->
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-HS18GM087S"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-HS18GM087S');
</script>
<!-- Global site tag (gtag.js) - Google Ads: 443990228 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-443990228"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-443990228');
</script>

<meta name="facebook-domain-verification" content="qnrmwkpzdpqjcs9ro3lbebdem2axds" />
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<meta name="keywords" content="THALYA" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
	<meta name="description" content="THALYA" />

	<title> THALYA	</title>

	<link href='https://fonts.googleapis.com/css?family=Raleway:400,100,200,300,500,600,700,800,900' rel='stylesheet' type='text/css'>

  <link rel="apple-touch-icon" sizes="57x57" href="static/favicon/apple-icon-57x57.png">
  <link rel="apple-touch-icon" sizes="60x60" href="static/favicon/apple-icon-60x60.png">
  <link rel="apple-touch-icon" sizes="72x72" href="static/favicon/apple-icon-72x72.png">
  <link rel="apple-touch-icon" sizes="76x76" href="static/favicon/apple-icon-76x76.png">
  <link rel="apple-touch-icon" sizes="114x114" href="static/favicon/apple-icon-114x114.png">
  <link rel="apple-touch-icon" sizes="120x120" href="static/favicon/apple-icon-120x120.png">
  <link rel="apple-touch-icon" sizes="144x144" href="static/favicon/apple-icon-144x144.png">
  <link rel="apple-touch-icon" sizes="152x152" href="static/favicon/apple-icon-152x152.png">
  <link rel="apple-touch-icon" sizes="180x180" href="static/favicon/apple-icon-180x180.png">
  <link rel="icon" type="image/png" sizes="192x192"  href="static/favicon/android-icon-192x192.png">
  <link rel="icon" type="image/png" sizes="32x32" href="static/favicon/favicon-32x32.png">
  <link rel="icon" type="image/png" sizes="96x96" href="static/favicon/favicon-96x96.png">
  <link rel="icon" type="image/png" sizes="16x16" href="static/favicon/favicon-16x16.png">
  <link rel="manifest" href="static/favicon/manifest.json">
  <meta name="msapplication-TileColor" content="#ffffff">
  <meta name="msapplication-TileImage" content="static/favicon/ms-icon-144x144.png">
  <meta name="theme-color" content="#ffffff">

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" >

	<link rel="stylesheet" type="text/css" href="static/css/style.desktop.css" />
	<link rel="stylesheet" type="text/css" href="static/css/style.tablet.css" />
	<link rel="stylesheet" type="text/css" href="static/css/style.tablet-small.css" />
	<link rel="stylesheet" type="text/css" href="static/css/style.mobile.css" />
	<link rel="stylesheet" type="text/css" href="static/css/style.retina.css" />
	<link rel="stylesheet" type="text/css" href="static/css/animate.css" />
  <link rel="stylesheet" type="text/css" href="static/css/custom-new.css?v=3456789dfghjk" />
  <link rel="stylesheet" href="https://api.chipware.co.za/css/flipclock.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css">
 <style>
   .row {
    display: -ms-flexbox;
    display: flex;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    margin-right: 0px;
    margin-left: 0px;
}
.owl-carousel .owl-controls .owl-pagination .owl-page.active {
    border: 1px solid #ffffff;
    background: #dc1c7d;
}


/*######### whatsapp btn ##########*/

.btn-whatsapp-pulse {
	background: #25d366;
	color: white;
	position: fixed;
	bottom: 20px;
	right: 20px;
	font-size: 32px;
	display: flex;
	justify-content: center;
	align-items: center;
	width: 0;
	height: 0;
	padding: 29px;
	text-decoration: none;
	border-radius: 50%;
	animation-name: pulse;
	animation-duration: 1.5s;
	animation-timing-function: ease-out;
	animation-iteration-count: infinite;
}

@keyframes pulse {
	0% {
		box-shadow: 0 0 0 0 rgba(37, 211, 102, 0.5);
	}
	80% {
		box-shadow: 0 0 0 14px rgba(37, 211, 102, 0);
	}
}

.btn-whatsapp-pulse-border {
	bottom: 75px;
	right: 10px;
	animation-play-state: paused;
}

.btn-whatsapp-pulse-border::before {
	content: "";
	position: absolute;
	border-radius: 50%;
	padding: 25px;
	border: 5px solid #25d366;
	opacity: 0.75;
	animation-name: pulse-border;
	animation-duration: 1.5s;
	animation-timing-function: ease-out;
	animation-iteration-count: infinite;
}

@keyframes pulse-border {
	0% {
		padding: 25px;
		opacity: 0.75;
	}
	75% {
		padding: 50px;
		opacity: 0;
	}
	100% {
		opacity: 0;
	}
}


 </style>
</head>

<body>
    
  <div class="menu-b">
    <div class="overlay" id="overlay">
      <nav class="overlay-menu">
        <ul>
          <li><a href="#">من نحن ؟</a></li>
          <li><a href="#">نصائح التطبيق</a></li>
          <li><a href="#">مكوناتنا</a></li>
        </ul>
      </nav>
    </div> 
  </div>

   <!-- header section -->
  <header style="z-index:99999; margin-bottom: 15px">
<div class="row top-header stick" style="z-index:99999;background: #4b2964;">   
  <div class="col-3 text-center ">
    <a href="precieuse-oil.php"  dir="rtl">زيت Précieuse للشعر</a> 
  </div>
  <div class="col-3 text-center ">
    <a href="precieuse-night.php" dir="rtl">كريم Précieuse للنهار</a>
  </div>
  <div class="col-3 text-center ">
    <a href="precieuse-day.php" dir="rtl">كريم Précieuse للّيل</a>
  </div>
  <div class="col-3 text-center first-menu-bg" >
    <a href="index.php"  class="first-menu"  dir="rtl">بّاك للعناية بالوجه و الشعر</a>
  </div>
</div>
</header>
 <div class="menu">
    <div class="row sticky" style="background: #DC1D7D;border-top: 17px solid #ffffff;">
   
    <div class="col-4">
      <img src="static/images/lp-1/thalya-logo.png" alt="" class="new-logo" style="z-index: 999;">
    </div>
    <div class="col-4">
      <a href="#form1" class="text-center black-btn button-cta cta-header" style="visibility: hidden;">
        اطلب الآن 
        <span>
          التوصيل مجاني لجميع المدن
        </span>
      </a>
    </div>
    <div class="col-4">
      <div class="button_container" id="toggle"><span class="top"></span><span class="middle"></span><span class="bottom"></span></div>
    </div>
 
  </div>
 </div>
 

  <style> 
  .video-responsive { 
overflow:hidden; 
padding-bottom:56.25%; 
position:relative; 
height:0;  
}

.video-responsive iframe {
left:0; 
top:0; 
height:100%;
width:100%;
position:absolute;
border-radius: 15px;
}
</style>






  <img src="static/images/lp-1/thalya-home-1.jpg" class="center produit-sur-mobile" style="width: 100% !important;height: auto;" alt="">


 
 <div style="text-align:center;background: #522367;">

  <br>
  <div class="divider"></div>
  <div class="text-center mt-3 mb-2" >
          <span class="title">
          طاليا عندها الحل لهاد المشاكل
          </span>
        </div>

  <div style="padding: 0 5px;">
    <img src="static/images/lp-1/img1.png" class="center produit-sur-mobile" style="width: 100% !important;
    padding: 3px; margin-bottom: 10px; height: auto;" alt="">


    <img src="static/images/lp-1/img2.png" class="center produit-sur-mobile"  style="
    margin-top: -15px;  width: 100% !important;height: auto;"  alt=""> 

    <img src="static/images/lp-1/img3.png" class="center produit-sur-mobile" style="width: 100% !important;
      padding: 3px;margin-bottom: 10px; height: auto;" alt="">
  </div>
        
        

        <div class="row">
          <div class="col-12 text-center">
            <a href="#form1" class="text-center black-btn  button-cta">
              اطلب الآن 
              <span>
                التوصيل مجاني لجميع المدن
              </span>
            </a>
          </div>
        </div>
        
       
        <br>
        <div class="divider"></div>

        <div class="text-center mt-3" >
          <span class="title">
            المميزات
          </span>
        </div>

        <div class="row pt-4" style="padding: 0 20px;">

          <div class="col-6"  style="text-align: right;">
            <img src="static/images/lp-1/produit-2.png" class="center"  style="width: 100% !important;height: auto;display: block;" alt="">
            <a href="javascript:;" dir="rtl" class="collspan"  onclick="accordion(3)"><img src="static/images/lp-1/icon-plus.png" alt=""> ترطيب البشرة  </a>
            <div class="collspan-info" id="collspan-3"> 
              <p dir="rtl">
                يمنحك كريم Précieuse  للنهار ترطيبا عميقا بفضل تركيبته المغذية بزبدة الشيا التي تدوم لفترة طويلة و يخفي شحوب البشرة ليترك لك مظهراً مشرقاً.              </p>
            </div>
            <a href="javascript:;" dir="rtl"  class="collspan"  onclick="accordion(4)"><img src="static/images/lp-1/icon-plus.png" alt="" style="margin-top: -4px;">  حماية البشرة من أضرار أشعة الشمس</a>
            <div class="collspan-info" id="collspan-4" > 
              <p dir="rtl">
                يرطب البشرة و يجدد الخلايا و يمنع الأشعة فوق البنفسجية من اختراق بشرتك تماما بفضل تركيبته الفعالة من خيرات الطبييعة مثل أكسيد الزنك.              </p>
            </div>
          </div>

          <div class="col-6 " style="text-align: right;">
            <img src="static/images/lp-1/produit-1.png" class="center"  style="width: 100% !important;height: auto;" alt="">
            <a href="javascript:;" dir="rtl" class="collspan" onclick="accordion(1)"><img src="static/images/lp-1/icon-plus.png" alt=""> القضاء على البقع الداكنة و آثار الحبوب  </a>
            <div class="collspan-info" id="collspan-1"> 
              <p dir="rtl">
                تساعد المكونات الموجودة في كريم Précieuse  للّيل كعرق السوس مثلا على التخلص من البقع الداكنة و  آثار حب الشباب.
              </p>
            </div>
            <a href="javascript:;" dir="rtl"  class="collspan" onclick="accordion(2)"><img src="static/images/lp-1/icon-plus.png" alt="" style="margin-top: -4px;">  تفتيح لون البشرة و إصلاحها </a>
            <div class="collspan-info" id="collspan-2" > 
              <p dir="rtl">
                يعمل كريمPrécieuse  للّيل من thalya  على تفتيح لون البشرة وتبييضها.
              </p>
            </div>
          </div>

          
          <div class="col-6 " style="text-align: right;position: relative; left: 30px ; top: 50px;z-index: 2;">
            <a href="javascript:;" dir="rtl" class="collspan" onclick="accordion(5)"><img src="static/images/lp-1/icon-plus.png" alt=""> توقيف تساقط الشعر  </a>
            <div class="collspan-info" id="collspan-5"> 
              <p dir="rtl">
                تعالج الزيوت الطبيعية تساقط الشعر وتقوي البصيلات وجذور الشعر.              </p>
            </div>
            <a href="javascript:;" dir="rtl"  class="collspan" onclick="accordion(6)"><img src="static/images/lp-1/icon-plus.png" alt="" style="margin-top: -4px;">  تسريع نمو الشعر و ملأ المناطق الفارغة في فروة الرأس </a>
            <div class="collspan-info" id="collspan-6" > 
              <p dir="rtl">
                تعمل المكونات الموجودة في زيت Précieuse للشعرمن thalya مثل زيت بذور العنب على زيادة معدل نمو الشعر و تغذية فروة الرأس.              </p>
            </div>
          </div>
          <div class="col-6" >
            <img src="static/images/lp-1/produit-3.png" class="center"  style="width: 100% !important;height: auto;position: relative; right: 40px ; z-index: 0;" alt="">
          </div>
        </div>

                  <div class="row">
          <div class="col-12 mt-5  text-center"  >
          <div class="text-center mb-2"  style="background: #db1d7c; border: 2px dashed #fff; border-radius: 10px; padding-top: 5px; padding-bottom: 5px;">
          <span class="title" dir="rtl">
          استفيدوا من تخفيضات تصل إلى 60%      
            </span>
          <br><br>
          <div class="clock" id="clock1"></div>
        </div>
          </div>
        </div>
                  

        <div class="row">
          <div class="col-12 mt-4  text-center">
        

            <a href="#form1" class="text-center black-btn  button-cta">
              اطلب الآن 
              <span>
                التوصيل مجاني لجميع المدن
              </span>
            </a>
          </div>
        </div>


        <br>
        <div class="divider"></div>

        <div class="text-center mt-3" >
          <span class="title">
            طريقة الإستعمال
          </span>
        </div>
       
        <img src="static/images/lp-1/utilisation.png" class="center produit-sur-mobile" style="width: 100% !important;height: auto;" alt="">

        <div class="row">
          <div class="col-12 text-center">
            <a href="#form1" class="text-center black-btn  button-cta">
              اطلب الآن 
              <span>
                التوصيل مجاني لجميع المدن
              </span>
            </a>
          </div>
        </div>


    <br> 


        <br>
        <div class="divider"></div>

        <div class="text-center mt-3" >
          <span class="title">
          علاش حنا رقم واحد ؟
                          </span>
        </div>
        
        <img src="static/images/lp-1/about-thalya.png" class="center produit-sur-mobile" style="width: 100% !important;height: auto;" alt="">

        <p dir="rtl" class="paragraph">
          كَّدوزي نهارك فالخدمة أو فالدار؟
          <br>

مابقيتيش كتلقاي الوقت باش تعتاني براسك ولا تشوفي راسك في المرايا!
القراية، الخدمة، الدار و الدراري نساوك فراسك. 
<br>
قصتك هي قصة كفاح و نضال لا ينتهي ، بطلتها نتي من الصباح لليل، داخل و خارج البيت.
جا الوقت باش تهلاي فراسك و تكوني ديما في مظهر زوين.
<br>
غادي تشوفي الفرق بعينيك! و بأثمنة مناسبة ليك!
أنت محتاجة العناية.
<br>
تهلاي فراسك هي أولويتك و مع thalya غادي تعاودي تيقي فراسك!


        </p>


        <div class="row">
          <div class="col-12 text-center">
            <a href="#form1" class="text-center black-btn  button-cta">
              اطلب الآن 
              <span>
                التوصيل مجاني لجميع المدن
              </span>
            </a>
          </div>
        </div>


  
<br><br>    

<div class="text-center mt-3" >
        <span class="title">
        شهادات نعتز بها
        </span>
      </div>
 <br>
      
 <img src="static/images/lp-1/certif.png" class="center produit-sur-mobile" style="width: 100% !important;height: auto;" alt="">

      <br>
      <div class="divider"></div>
      
      <div class="text-center mt-3" >
        <span class="title">
          آراء زبائننا
        </span>
      </div>
 


    <div class="inner-block text-center"> 
      <h2 dir="rtl" style="font-size: 20px;color: #fde3c7;">ما يقول الزبناء عن Thalya </h2> 

      <div class="carousel-testimonials">
        <article class="item-1">
            <figure></figure>
          <div class="text">
          <p>
            من ولدت، مبقيتش كنديها فراسي بصفة نهائية، مسؤوليات الدار كبرات و مع كلست من الخدمة ما بقيتش كنلقا داعي و لا سبب باش نعتاني بالبشرة ديالي واقي الشمس هو لخر ما كنديروش. لكن جربت برودويات ديال thalya و صراحة ما عندي مانقول روعة. وليت كنحاول نرجع للروتين ديالي و نستعمل الباك كل نهار.
          </p>
           
            <b style="margin-top: 20px;">
               <img src="static/images/lp-1/stars.png" class="stars" alt="">
               <br>
               الهام - الدار البيضاء
              </b>
          </div>
        </article>
        <article class="item-2">
          
          <figure></figure>
          <div class="text">
            <p> 
            أنا قهرني وجهي فينما كاينا شي حاجة كنجربها غالية و لا رخيصة، طحت فلاباج ديالكم، الأثمنة واعرين و النتيجة حتا هي ، عجبني لييكرو ديال الشمس بزاف ممدهنش و بحالا ماديرا والو طوب أما كريم لي كيدار بليل قريب يسالي و البقع حتا هوما غادين و كينقصوا. 

          </p>
            <b>
               <img src="static/images/lp-1/stars.png" class="stars" alt="">
               <br>
               ملاك - الرباط 
              </b>
          </div>
        </article> 

        <article class="item-3">
          
          <figure></figure>
          <div class="text">
            <p> 
            خديت الباك كامل و صراحة طوب شعري نقص فالتساقط و كريمات ديال الوجه خطييرين البنات ما تفلتوهومش . 

          </p>
            <b>
               <img src="static/images/lp-1/stars.png" class="stars" alt="">
               <br>
               زهرة - الناظور
              </b>
          </div>
        </article> 
        
      </div>

    </div>

    <br>
    <div class="divider"></div>
    
    <div class="text-center mt-3" >
      <span class="title">
      إكتشفو عروضنا الحالية  
      </span>
    </div> 

   

               <div class="text-center mt-3"  >
            <span class="title" dir="rtl" style="color: #db1d7c;font-weight:bold;background: #fff;">
            استفيدوا من تخفيضات تصل إلى 60%      </span>
          </div>
          
<style>
  .btn-acheter-pack{ 
    background: #db1d7c;
    padding: 5px;
    color: #fff;
    font-size: 24px;
  }
</style>

    <div class="inner-block" style="padding: 20px;"> 

    <div class="text-center" style="border:8px solid #fff; margin-bottom: 24px;">
    <img src="static/images/lp-1/p1-1.webp" data-product="0" class="center produit-sur-mobile gotoform" style="width: 100% !important;height: auto;cursor: pointer;" alt="" >
    <div  class="gotoform btn-acheter-pack"  data-product="0" > اطلب الآن </a>
    </div>
   </div>

   <div class="text-center" style="border:8px solid #fff; margin-bottom: 24px;">
    <img src="static/images/lp-1/p2-2.webp" data-product="1" class="center produit-sur-mobile gotoform" style="width: 100% !important;height: auto;cursor: pointer;" alt="" >
    <div  class="gotoform btn-acheter-pack"  data-product="1" > اطلب الآن </a>
    </div>
   </div>

   <div class="text-center" style="border:8px solid #fff; margin-bottom: 24px;">
    <img src="static/images/lp-1/p3-3.webp" data-product="2" class="center produit-sur-mobile gotoform" style="width: 100% !important;height: auto;cursor: pointer;" alt="" >
    <div  class="gotoform btn-acheter-pack"  data-product="2" > اطلب الآن </a>
    </div>
   </div>
 

    
 
    </div>
 
  
 



  <section style="background: #522367 !important;" >
    <img src="static/images/lp-1/img-9.jpg" class="center produit-sur-mobile " style="width: 100% !important;  height: auto;" alt="">

    <div style="background: #fff;border-radius: 20px;margin:20px 20px 0px 20px">
    <div class="price" id="pack-choisi" style="border:none !important;">
        روتين الوجه و الشعر
    </div>

      <form action="thankyou.php" method="post" id="form1" class="iefix"  >

                  <input type='hidden' name='utm_source' value=""/>
          

        <div class="" style="padding: 20px;">
         
        
        <div class="form-holder">
          <select   name="pays" id="pays"  class="first-name"  dir="rtl">
            <option value="1">المملكة المغربية 🇲🇦</option>
            <option value="2"> خارج المغرب 🌍</option>
          </select>
        </div>
      
        <div class="form-holder" id="msgRedirection" style="display:none;background: #4ebf29; color: #ffffff;padding: 20px;text-align: center;font-size: 1rem;font-weight: bold;">ستتم إعادة توجيهك إلى متجرنا الدولي ...</div>

        

        <div class="form-holder">
          <select   name="product" id="product"   class="first-name"  dir="rtl">
          <option value="42026842194177">روتين الوجه و الشعر </option> 
          <option value="42026841964801">كريم لليل + كريم للنهار</option> 
          <option value="42026842161409"> إثنان زيت الشعر</option> 

          </select>
        </div>

        <div class="form-holder" >
          <input type="text" name="first_name" placeholder="الإسم والنسب" class="first-name"   dir="rtl"/>
        </div>
      
        <div class="form-holder">
          <input type="tel" name="phone" placeholder="رقم الهاتف" class="first-name"   dir="rtl"/>
        </div>
        
        <div class="form-holder">
          <input type="text" name="city" placeholder="المدينة" class="first-name"   dir="rtl"/>
        </div>
        
        <div class="form-holder">
          <textarea   name="address" placeholder="العنوان" class="first-name" rows="5"  dir="rtl" ></textarea>
        </div>

         
        <div class="text-center">
          <button type="submit" class="button-new">اطلب الان</button>
        </div>

        <div class="price" id="price">
          329 درهم  ( توصيل مجاني )
        </div>

        </div>
      </form>
      <BR>
    </div>
  </section>

  <!-- footer section -->

  <div class="row"  style="background: #522367 !important;padding-top:30px" >
  
    <div class="col-md-12 text-center"> 
    <div class="text-center mt-3 mb-4" >
      <span class="title">
      الأسئلة الشائعة
      </span>
    </div> 
      <h4 dir="rtl" style="color:#fff">متى سأتوصل بالمنتج و ما طريقة الدفع ؟</h4>
      <p dir="rtl" style="color:#fff">
      الأمر بسيط جدا بعد أن تطلب المنتج من خلال ملا الاستمارة سيتصل بك أحد موظفي الشركة ليؤكد معك الطلب، وسنرسل لك المنتج في غضون 24 الى 48 ساعة (الدفع يكون عند الاستلام) لدينا فريق توصيل محترف يوصل لك المنتج أينما كنت خلال مدة 24 الى 48 ساعة خدمة التوصيل مجانية %100 فأنت لست بحاجة لدفع أية مصاريف إضافية
      </p> 

      <h4 dir="rtl" style="color:#fff">خدمة ما بعد البيع</h4>
      <p dir="rtl" style="color:#fff">
      عكس باقي الشركات التي تبيعك المنتج و تتركك وحدك شركتنا تتوفر على فريق مدرب خصيصا للإجابة على تساؤلات الزبائن بعد البيع فهدف الشركة هو السمعة الطيبة و هذا يأتي من إرضاء الزبائن و البقاء معهم إلى حين التوصل إلى النتيجة المطلوبة
      </p>

      <div class="text-center" style="background: #fff; margin: 10px; padding: 10px; border-radius: 15px;">
      <img src="static/images/lp-1/quality.png" style="height: 78px; margin: 0 auto;" alt="">
      <h4 dir="rtl" style="color:#db1d7c">الجودة مضمونة</h4>
      <p dir="rtl">
      جميع منتوجاتنا ذات جودة عالية و مصممة بمعايير عالمية لتعطي أفضل النتائج
      </p>
      </div>

      <div class="text-center" style="background: #fff; margin: 10px; padding: 10px; border-radius: 15px;">
      <img src="static/images/lp-1/call.png" style="height: 78px; margin: 0 auto;" alt="">
      <h4 dir="rtl" style="color:#db1d7c">إستشارة</h4>
      <p dir="rtl">
      نقدم دعم تقني لعملائنا بالمجان لأن هدفنا هو إرضاؤكم      
      </p>
      </div>

      <div class="text-center" style="background: #fff; margin: 10px; padding: 10px; border-radius: 15px;">
      <img src="static/images/lp-1/money.png" style="height: 78px; margin: 0 auto;" alt="">
      <h4 dir="rtl" style="color:#db1d7c">أثمنة  تنافسية</h4>
      <p dir="rtl">
      منتوجاتنا تتميز بالجودة العالية مع أثمنة في المستوى      
      </p>
      </div>


      <div class="text-center" style="background: #fff; margin: 10px; padding: 10px; border-radius: 15px;">
      <img src="static/images/lp-1/deliv.png" style="height: 78px; margin: 0 auto;" alt="">
      <h4 dir="rtl" style="color:#db1d7c">التوصيل المجاني</h4>
      <p dir="rtl">
      نقدم لكم خاصية الشحن المجاني لجميع أنحاء المملكة     
      </p>
      </div>


    </div>
  </div>
 
    <a href="whatsapp://send?phone=212520607060&text=SALAM" class="btn-whatsapp-pulse btn-whatsapp-pulse-border">
    <i class="fab fa-whatsapp"></i>
  </a>
  
 

  <section class="footer-section" style="background: #361a4a !important;" >
  <div class="">
    <div class="col-md-12">
    <p style="    text-align: center;
    font-size: 9px;
    color: #fff;
    padding: 15px;
    line-height: 1.5;">©️ 2022 THALYA
    THIS SITE IS NOT A PART OF THE FACEBOOK WEBSITE OR FACEBOOK INC.
    ADDITIONALLY, THIS SITE IS NOT ENDORSED BY FACEBOOK IN ANY WAY.
    FACEBOOK IS A TRADEMARK OF FACEBOOK, INC.</p>
    </div>
  </div>
</section> 


  <section class="fixed-mobile-button" style="background: #E31875;">
    <a href="#form1" class="text-center black-btn  button-cta">
      اطلب الآن 
      <span>
        التوصيل مجاني لجميع المدن
      </span>
    </a>
  </section>

 


 




<script src="static/js/lib/jquery-3.0.0.min.js"></script>
<script src="static/js/lib/owl.carousel.min.js" type="text/javascript"></script>

<script src="static/js/scripts.js" type="text/javascript"></script>

<script src="static/js/lib/jquery.validate.js" type="text/javascript"></script>
<script src="https://api.chipware.co.za/js/flipclock-min.js"></script>




<script type="text/javascript">

   
$(document).ready(function(){
 

 
  $("#form1").validate({
    // Specify validation rules
    rules: {
      // The key name on the left side is the name attribute
      // of an input field. Validation rules are defined
      // on the right side
      first_name: "required",
      city: "required",
      phone:{
       required: true,
      number: true
      },
      address:"required"
    },
    // Specify validation error messages
    messages: {
      first_name: "Veuillez insérer votre nom et prénom",
      city: "Veuillez insérer votre ville",
      tel: 'Veuillez insérer un numéro de téléphone',
      address:"Veuillez insérer votre adresse de livraison"
    },
    // Make sure the form is submitted to the destination defined
    // in the "action" attribute of the form when valid
    submitHandler: function(form) {
      form.submit();
    }

  });
 
  
// owl slider 
    $('.carousel-testimonials').owlCarousel({
        items: 3,
        itemsDesktop: [1023,3],
        itemsTablet: [959,2],
        itemsMobile : [768,2],
        singleItem : false,
        autoPlay: 7000,
        paginationSpeed: 1600,
        navigation: false,
        pagination: true,
        responsive: true,
        paginationNumbers: false,
        stopOnHover: true
    });
 
 
    $('.carousel-ingred, .carousel-ingred-2').owlCarousel({
        items: 3,
        itemsDesktop: [1023,1],
        itemsTablet: [959,1],
        itemsMobile : [768,1],
        singleItem : false,
        autoPlay: 2000,
        paginationSpeed: 700,
        navigation: false,
        pagination: true,
        responsive: true,
        paginationNumbers: false,
        stopOnHover: true
    }); 

    
// end owl slider 

 $('#product').on('change', function(){
  changeTextPrice();
 })

 function changeTextPrice() {
  var selected = $('#product').prop('selectedIndex');
  if(selected== 0){
    $('#price').html(' 329 درهم  ( توصيل مجاني )');
    $('#pack-choisi').html('روتين الوجه و الشعر');
  }
  else if(selected== 1){$('#price').html('279 درهم  ( توصيل مجاني )');$('#pack-choisi').html('كريم لليل + كريم للنهار');}
  else if(selected== 2){$('#price').html('279 درهم  ( توصيل مجاني )');$('#pack-choisi').html('إثنان زيت الشعر');}
 
  else{$('#price').html(' 329 درهم  ( توصيل مجاني )');$('#pack-choisi').html('روتين الوجه و الشعر');}
 }
 
$(".gotoform").click(function(e) {
    // Prevent a page reload when a link is pressed

    e.preventDefault();

    var indexProduit = $(this).data('product');

    $('#product option').eq(indexProduit).prop('selected', true);

    changeTextPrice();

    $('html,body').animate({
        scrollTop: $("#form1").offset().top
    }, 'slow'); 




});

$('#pays').on('change', function(){
  var selected = $(this).prop('selectedIndex');
  if(selected== 1){
    $('#msgRedirection').fadeIn();
    setTimeout(function(){
      window.location.replace("https://thalya.net/products/pack-thalya");
    }, 2000);

  }

 })

 $('#toggle').click(function() {
   $(this).toggleClass('active');
   $('#overlay').toggleClass('open');
  });



});
/* ######### accordion benifits ########### */
function accordion(id){
  $('#collspan-'+id).slideToggle();
}

/* ######### sticky menu 1 ########### */
let timeout = 0
let previousScrollY = 0
function scan() {
  const sticky = document.querySelector('header')
  let scrollY = window.scrollY
  let scrollingDirection = scrollY - previousScrollY
  if (scrollY > sticky.offsetHeight) {
    if (scrollingDirection < 0) {
      sticky.setAttribute('data-visible', 'sticky');
      $(".sticky").css({"top":"43px"});
    } else if (scrollingDirection > 0) {
      sticky.setAttribute('data-visible', 'false');
      $(".sticky").css({"top":"0px"});
    }
  } else {
    sticky.setAttribute('data-visible', 'true')
  }
  previousScrollY = scrollY
}
window.onscroll = function() {
  clearTimeout();
  timeout = setTimeout(scan, 10)
}

/* ######### sticky menu 2 ########### */
var div_top = $('.menu').offset().top;

$(window).scroll(function() {
    var window_top = $(window).scrollTop() - 0;
    if (window_top > div_top) {
        if (!$('.menu').is('.sticky')) {
            $('.menu').addClass('sticky');
        }
    } else {
        $('.menu').removeClass('sticky');
    }
});

//* Target Date Must be Like Below
//var date = new Date("June 15, 2016 12:45:00");


 

  var clock;
// Instantiate a coutdown FlipClock 172800 = 48hrs
clock = $('#clock1').FlipClock(86400, {
	clockFace: 'HourlyCounter',
	countdown: true,
	showSeconds: true,
	callbacks: {
		start: function() {
			//$('.message').html('The clock has started!');
		},
		stop: function() {
		//	$('.message').html('The clock has stopped!');
		}
	}
});


 /*
// Just for running purpose
//=======================================
var start = new Date();
start.setDate(start.getDate());
start.setHours(0,0,0,0)
//======================================
var now   = new Date();

var diff = (now.getTime() - start.getTime()) / 1000;

	var clock = $('#clock1').FlipClock(diff, {
		clockFace: 'HourlyCounter',
    language: 'ar',
		countdown: false,
		showSeconds: true
  });
*/
  
 

</script>
 <style>
   .flip-clock-label{
     color: #fff !important;
     font-size: 16px !important;
   }
@media screen and (max-width: 700px) {
    .clock {  display: block; width: 100%; }

    .flip-clock-wrapper ul { height: 50px; line-height: 50px; }
    .flip-clock-wrapper ul li a div.up:after { top: 24px; }
    .flip-clock-divider { height: 50px; }
    .flip-clock-dot { height: 6px; width: 6px; left: 7px;}
    .flip-clock-dot.top { top: 17px; }
    .flip-clock-dot.bottom { bottom: 8px; }

    .flip-clock-divider .flip-clock-label { font-size: 11px; }
    .flip-clock-divider.days .flip-clock-label { right: -58px; }
    .flip-clock-divider.hours .flip-clock-label { right: -58px; }
    .flip-clock-divider.minutes .flip-clock-label { right: -64px; }
    .flip-clock-divider.seconds .flip-clock-label { right: -64px; }
    .flip-clock-wrapper ul li { line-height: 50px; }
    .flip-clock-wrapper ul { width: 37px; }
    .flip-clock-wrapper ul li a div div.inn { font-size: 30px; }
}
 </style>
</body>

</html>
