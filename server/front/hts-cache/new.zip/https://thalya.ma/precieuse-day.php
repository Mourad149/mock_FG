<!DOCTYPE>
<html lang="ar">
  
<head>
<!-- Hotjar Tracking Code for https://landingpage.thalya.ma/precieuse-day.php -->
  <script>
    (function(h,o,t,j,a,r){
        h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};
        h._hjSettings={hjid:2702354,hjsv:6};
        a=o.getElementsByTagName('head')[0];
        r=o.createElement('script');r.async=1;
        r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;
        a.appendChild(r);
    })(window,document,'https://static.hotjar.com/c/hotjar-','.js?sv=');
</script>
  <!-- Facebook Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '174008244912245');
fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=174008244912245&ev=PageView&noscript=1"
/></noscript>
<!-- End Facebook Pixel Code -->
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-HS18GM087S"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-HS18GM087S');
</script>
<!-- Global site tag (gtag.js) - Google Ads: 443990228 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-443990228"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-443990228');
</script>
<meta name="facebook-domain-verification" content="qnrmwkpzdpqjcs9ro3lbebdem2axds" />
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<meta name="keywords" content="THALYA" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
	<meta name="description" content="THALYA" />

	<title> THALYA	</title>

	<link href='https://fonts.googleapis.com/css?family=Raleway:400,100,200,300,500,600,700,800,900' rel='stylesheet' type='text/css'>

  <link rel="apple-touch-icon" sizes="57x57" href="static/favicon/apple-icon-57x57.png">
  <link rel="apple-touch-icon" sizes="60x60" href="static/favicon/apple-icon-60x60.png">
  <link rel="apple-touch-icon" sizes="72x72" href="static/favicon/apple-icon-72x72.png">
  <link rel="apple-touch-icon" sizes="76x76" href="static/favicon/apple-icon-76x76.png">
  <link rel="apple-touch-icon" sizes="114x114" href="static/favicon/apple-icon-114x114.png">
  <link rel="apple-touch-icon" sizes="120x120" href="static/favicon/apple-icon-120x120.png">
  <link rel="apple-touch-icon" sizes="144x144" href="static/favicon/apple-icon-144x144.png">
  <link rel="apple-touch-icon" sizes="152x152" href="static/favicon/apple-icon-152x152.png">
  <link rel="apple-touch-icon" sizes="180x180" href="static/favicon/apple-icon-180x180.png">
  <link rel="icon" type="image/png" sizes="192x192"  href="static/favicon/android-icon-192x192.png">
  <link rel="icon" type="image/png" sizes="32x32" href="static/favicon/favicon-32x32.png">
  <link rel="icon" type="image/png" sizes="96x96" href="static/favicon/favicon-96x96.png">
  <link rel="icon" type="image/png" sizes="16x16" href="static/favicon/favicon-16x16.png">
  <link rel="manifest" href="static/favicon/manifest.json">
  <meta name="msapplication-TileColor" content="#ffffff">
  <meta name="msapplication-TileImage" content="static/favicon/ms-icon-144x144.png">
  <meta name="theme-color" content="#ffffff">

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" >

	<link rel="stylesheet" type="text/css" href="static/css/style.desktop.css" />
	<link rel="stylesheet" type="text/css" href="static/css/style.tablet.css" />
	<link rel="stylesheet" type="text/css" href="static/css/style.tablet-small.css" />
	<link rel="stylesheet" type="text/css" href="static/css/style.mobile.css" />
	<link rel="stylesheet" type="text/css" href="static/css/style.retina.css" />
	<link rel="stylesheet" type="text/css" href="static/css/animate.css" />
	<link rel="stylesheet" type="text/css" href="static/css/custom.css?v=45678" />
 <style>
   .row {
    display: -ms-flexbox;
    display: flex;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    margin-right: 0px;
    margin-left: 0px;
}
 </style>
</head>

<body>
    
  <div class="menu-b">
    <div class="overlay" id="overlay">
      <nav class="overlay-menu">
        <ul>
          <li><a href="#">من نحن ؟</a></li>
          <li><a href="#">نصائح التطبيق</a></li>
          <li><a href="#">مكوناتنا</a></li>
        </ul>
      </nav>
    </div> 
  </div>

   <!-- header section -->
  <header style="z-index:99999; margin-bottom: 15px">
<div class="row top-header stick" style="z-index:99999;background: #4b2964;">   
  <div class="col-3 text-center ">
    <a href="precieuse-oil.php"  dir="rtl">زيت Précieuse للشعر</a> 
  </div>
  <div class="col-3 text-center ">
    <a href="precieuse-night.php" dir="rtl">كريم Précieuse للنهار</a>
  </div>
  <div class="col-3 text-center  first-menu-bg">
    <a href="precieuse-day.php"  class="first-menu"  dir="rtl">كريم Précieuse للّيل</a>
  </div>
  <div class="col-3 text-center" >
    <a href="index.php" dir="rtl"> بّاك للعناية بالوجه و الشعر </a>
  </div>
</div>
</header>
 <div class="menu">
    <div class="row sticky" style="background: #DC1D7D;border-top: 17px solid #ffffff;">
   
    <div class="col-4">
      <img src="static/images/lp-1/thalya-logo.png" alt="" class="new-logo">
    </div>
    <div class="col-4">
      <a href="#form1" class="text-center black-btn button-cta cta-header">
        اطلب الآن 
        <span>
          التوصيل إلى جميع أنحاء المغرب
        </span>
      </a>
    </div>
    <div class="col-4">
      <div class="button_container" id="toggle"><span class="top"></span><span class="middle"></span><span class="bottom"></span></div>
    </div>
 
  </div>
 </div>
 

  

  <img src="static/images/lp-2/home-2-v3.jpg" class="center produit-sur-mobile" style="width: 100% !important;height: auto;" alt="">


 
 <div style="text-align:center;background: #522367;">

  <br>
  <div class="divider"></div>

  <div style="padding: 0 0px;">
    <img src="static/images/lp-2/thalya-1.png" class="center produit-sur-mobile" style="width: 100% !important;
    padding: 3px; margin-bottom: 10px; height: auto;" alt="">

    <p dir="rtl" class="paragraph" style="position: relative;top:-90px;font-size: 19px; line-height: 32px;">
      بالليل  كتتجدد بشرتك وكتصلح الأضرار <br> لي تعرضات ليها فالنهار. 

      <br>
      وبالليل أيضاً كتشتغل المكونات النشطة لي في كريم thalya بشكل أفضل وكتعطي الفعالية ديالها و كتدعم  الإصلاح الليلي للبشرة، فكتقضي على البقع الداكنة و كتصلح مشاكل البشرة مع توحيد لونها و اعطائها إشراقة.
    </p> 

  </div>
        
        

        <div class="row">
          <div class="col-12 text-center">
            <a href="#form1" class="text-center black-btn  button-cta">
              اطلب الآن 
              <span>
                التوصيل إلى جميع أنحاء المغرب
              </span>
            </a>
          </div>
        </div>
        
       
        <br>
        <div class="divider"></div>

        <div class="text-center mt-3" >
          <span class="title">
            المميزات
          </span>
        </div>

        <div class="row pt-4" style="padding: 0 20px;">

          <div class="col-6"  style="text-align: right;">
            <a href="javascript:;" dir="rtl" class="collspan"  onclick="accordion(3)"><img src="static/images/lp-1/icon-plus.png" alt="">  توحيد لون البشرة بشكل واضح   </a>
            <div class="collspan-info" id="collspan-3"> 
              <p>
                بفضل تركيبته المغذية بزبدة الشيا التي تدوم لفترة طويلة ، يوحد كريمPrécieuse  للّيل من thalya  لون البشرة و يخفي شحوبها ليترك لك مظهراً مشرقاً.
              </p>
            </div>
            <a href="javascript:;" dir="rtl"  class="collspan"  onclick="accordion(4)"><img src="static/images/lp-1/icon-plus.png" alt="" style="margin-top: -4px;">  إعطاء  إشراقة للبشرة </a>
            <div class="collspan-info" id="collspan-4" > 
              <p>
                غني بالعديد من مضادات الأكسدة، يساعد زيت اللوز الحلو على ترطيب البشرة وتخفيف جفافها و الحفاظ على بقاء البشرة ناعمة، رطبة، وخالية من التجاعيد و التخلص من البقع الداكنة.
              </p>
            </div>
          </div>

          <div class="col-6 " style="text-align: right;">
             <a href="javascript:;" dir="rtl" class="collspan" onclick="accordion(1)"><img src="static/images/lp-1/icon-plus.png" alt=""> القضاء على البقع الداكنة و تفتيح لون البشرة </a>
            <div class="collspan-info" id="collspan-1"> 
              <p>
                تساعد المكونات الموجودة في كريمPrécieuse  للّيل كعرق السوس مثلا على التخلص من البقع الداكنة مما يعمل على تفتيح لون البشرة وتبييضها.               </p>
            </div>
            <a href="javascript:;" dir="rtl"  class="collspan" onclick="accordion(2)"><img src="static/images/lp-1/icon-plus.png" alt="" style="margin-top: -4px;"> مكافحة  آثار حب الشباب و البثور </a>
            <div class="collspan-info" id="collspan-2" > 
              <p>
                تساعد مكونات زيت اللوز الحلو كفيتامين أ وبعض المعادن الصحية، مثل: الزنك، والمغنيسيوم، والبوتاسيوم، والمنغنيزيوم، والفسفور، على تهدئة خلايا الجلد التالفة، تحفيز تجدد خلايا البشرة ومقاومة العديد من مشاكلها كحب الشباب.              </p>
            </div>
          </div>

           
        </div>


      
        <div class="row">
          <div class="col-12 text-center">
            <a href="#form1" class="text-center black-btn  button-cta">
              اطلب الآن 
              <span>
                التوصيل إلى جميع أنحاء المغرب
              </span>
            </a>
          </div>
        </div>


        <br>
        <div class="divider"></div>

        <div class="text-center mt-3" >
          <span class="title">
            المكونات
          </span>
        </div>
       
        <img src="static/images/lp-2/ingr.jpg" class="center produit-sur-mobile mt-4" style="width: 100% !important;height: auto;" alt="">

        <div class="text-center ingr mt-4">
          <h4>عرق السوس</h4>
          <span class="mini-divider"></span>
          <p >يساعد على تفتيح البشرة، وعلاج تصبغات الجلد الداكنة</p>
          <br> 
          <h4>زيت الأركان</h4>
          <span class="mini-divider"></span>
          <p >يساهم في ترطيب بشرة الوجه، ومنحها النضارة</p>
          <br> 
          <h4>زيت اللوز الحلو</h4>
          <span class="mini-divider"></span>
          <p >يساعد على ترطيب البشرة وتخفيف جفافها</p>
          <br> 
          <h4>زيت فول الصويا</h4>
          <span class="mini-divider"></span>
          <p >يرطب البشرة بعمق و يغذيها</p>
          <br> 
          <h4>  زبدةالــشــيـا  </h4>
          <span class="mini-divider"></span>
          <p >تعمل على توحيد لون البشرة و إزالة النمش والكلف</p>
        </div>
        


        <div class="row">
          <div class="col-12 text-center">
            <a href="#form1" class="text-center black-btn  button-cta">
              اطلب الآن 
              <span>
                التوصيل إلى جميع أنحاء المغرب
              </span>
            </a>
          </div>
        </div>


        <br>
        <div class="divider"></div>

        <div class="text-center mt-3" >
          <span class="title">
            طريقة الإستعمال
          </span>
        </div>
       
        <img src="static/images/lp-2/utilisa.png" class="center produit-sur-mobile" style="width: 100% !important;height: auto;" alt="">

        <div  class="text-center utilisation" >
          لنتائج مثالية، يفضل استعمال كريم   Précieuse  النهار من thalya كل صباح
        </div>
        
        <div class="text-center utilisation" style="margin-top: 5px;">
          يستخدم كريم Précieuse لّليل من thalya  كمكمل لكريم للنهار من thalya  للحصول على نتائج فعالة

        </div>
<br>
        <div class="row">
          <div class="col-12 text-center">
            <a href="#form1" class="text-center black-btn  button-cta">
              اطلب الآن 
              <span>
                التوصيل إلى جميع أنحاء المغرب
              </span>
            </a>
          </div>
        </div>


        <br>
        <div class="divider"></div>

        <div class="text-center mt-3" >
          <span class="title">
            من نحن ؟
          </span>
        </div>
        
        <img src="static/images/lp-1/about-thalya.png" class="center produit-sur-mobile" style="width: 100% !important;height: auto;" alt="">

        <p dir="rtl" class="paragraph">
          كَّدوزي نهارك فالخدمة أو فالدار؟
          <br>

مابقيتيش كتلقاي الوقت باش تعتاني براسك ولا تشوفي راسك في المرايا!
القراية، الخدمة، الدار و الدراري نساوك فراسك. 
<br>
قصتك هي قصة كفاح و نضال لا ينتهي ، بطلتها نتي من الصباح لليل، داخل و خارج البيت.
جا الوقت باش تهلاي فراسك و تكوني ديما في مظهر زوين.
<br>
غادي تشوفي الفرق بعينيك! و بأثمنة مناسبة ليك!
أنت محتاجة العناية.
<br>
تهلاي فراسك هي أولويتك و مع thalya غادي تعاودي تيقي فراسك!


        </p>


        <div class="row">
          <div class="col-12 text-center">
            <a href="#form1" class="text-center black-btn  button-cta">
              اطلب الآن 
              <span>
                التوصيل إلى جميع أنحاء المغرب
              </span>
            </a>
          </div>
        </div>


  

      

      <br>
      <div class="divider"></div>
      
      <div class="text-center mt-3" >
        <span class="title">
          آراء زبائننا
        </span>
      </div>
 


    <div class="inner-block text-center"> 
      <h2 dir="rtl" style="font-size: 20px;color: #fde3c7;">ما يقول الزبناء عن Thalya </h2> 

      <div class="carousel-testimonials">
        <article class="item-1">
            <figure></figure>
          <div class="text">
          <p dir="rtl">
            الملمس ديال الكريم ماكيبانش تماما عند التطبيق، بحالا مادايرا حتا شي كريم في وجهي، ريحتوا واعرة و أهم حاجة ليطاش مابقاوش كيبانو.

          </p>
           
            <b style="margin-top: 20px;">
               <img src="static/images/lp-1/stars.png" class="stars" alt="">
               <br>
               يسرى ـ الدارالبيضاء
            </b>
          </div>
        </article>
        <article class="item-2">
          
          <figure></figure>
          <div class="text">
          <p dir="rtl">
            كناخد الوقت ديالي باش نستعمل منتجات thalya صراحة ما كنتش كنقدر نخرج بلا بودرة الوجه لكن دابا رجعات ليا تيقتي فراسي و وليت مداومة على الكريم النهاري باش يتحيدوا ليا لي تراس.
          </p>
            <b>
               <img src="static/images/lp-1/stars.png" class="stars" alt="">
               <br>
               ضحى ـ سلا
            </b>
          </div>
        </article> 
        <article class="item-1">
          <figure></figure>
        <div class="text" dir="rtl">
        <p>
          عجبني الكريم بزاف، كيرطب البشرة وكيوحد اللون ديالها، كنستعملوا يوميا باش نحيد البقع السوداء على وجهي.

        </p>
         
          <b style="margin-top: 20px;">
             <img src="static/images/lp-1/stars.png" class="stars" alt="">
             <br>
             ليلى ـ الدار البيضاء
            </b>
        </div>
      </article>
      <article class="item-2">
        
        <figure></figure>
        <div class="text">
        <p dir="rtl">
          صراحة طحت فأفضل كريم لتفتيح البشرة، كنت كنحشم نخرج بوجهي عامر بلي طاش .كلشي لاحظ الفرق على وجهي بعد فترة قصيرة من الاستخدام.
        </p>
          <b>
             <img src="static/images/lp-1/stars.png" class="stars" alt="">
             <br>
             سلمى ـ الرباط
            </b>
        </div>
      </article> 
        
      </div>

    </div>

    <br>
    <div class="divider"></div>
    
    <div class="text-center mt-3" >
      <span class="title">
        اكتشفوا عروضنا
      </span>
    </div>

    


    <div class="inner-block" style="padding: 40px;"> 

     
   <img src="static/images/lp-2/p-a.jpg" data-product="0" class="center produit-sur-mobile product-mobile gotoform" style="width: 100% !important;margin-bottom: 10px; height: auto;cursor: pointer;" alt="" >

    <img src="static/images/lp-2/p-b.jpg"  data-product="1" class="center produit-sur-mobile product-mobile gotoform" style="width: 100% !important; margin-bottom: 10px; height: auto;cursor: pointer;" alt="" >

    <img src="static/images/lp-1/p1.jpg" data-product="2" class="center produit-sur-mobile product-mobile gotoform" style="width: 100% !important; margin-bottom: 10px; height: auto;cursor: pointer;" alt="" >

    </div>


    
 
    </div>
 
  
 



  <section style="background: #522367 !important;" >
    <img src="static/images/lp-1/img-9.jpg" class="center produit-sur-mobile " style="width: 100% !important;  height: auto;" alt="">

    <div style="background: #fff;border-radius: 20px;margin:30px 30px 0px 30px">
      <form action="thankyou.php" method="post" id="form1" class="iefix"  >
      	<input type='hidden' name='utm_source' value=""/>
        <div class="" style="padding: 20px;">
         
        
        <div class="form-holder">
          <select   name="pays" id="pays"  class="first-name"  dir="rtl">
            <option value="0">المملكة المغربية</option>
            <option value="0">خارج المغرب</option>
          </select>
        </div>
      
        <div class="form-holder" id="msgRedirection" style="display:none;background: #4ebf29; color: #ffffff;padding: 20px;text-align: center;font-size: 1rem;font-weight: bold;">ستتم إعادة توجيهك إلى متجرنا الدولي ...</div>

        <div class="form-holder">
          <select   name="product" id="product"   class="first-name"  dir="rtl">
          <option value="42031525200129"> إثنان كريم لليل</option> 
          <option value="42026841964801">كريم لليل + كريم للنهار</option> 
          <option value="42026842194177">روتين الوجه و الشعر </option> 
          </select>
        </div>

        <div class="form-holder" >
          <input type="text" name="first_name" placeholder="الإسم والنسب" class="first-name"   dir="rtl"/>
        </div>
      
        <div class="form-holder">
          <input type="tel" name="phone" placeholder="رقم الهاتف" class="first-name"   dir="rtl"/>
        </div>
        
        <div class="form-holder">
          <input type="text" name="city" placeholder="المدينة" class="first-name"   dir="rtl"/>
        </div>
        
        <div class="form-holder">
          <textarea   name="address" placeholder="العنوان" class="first-name" rows="5"  dir="rtl" ></textarea>
        </div>

         
        <div class="text-center">
          <button type="submit" class="button-new">اطلب الان</button>
        </div>

        <div class="price" id="price">
          279 درهم  ( توصيل مجاني )
        </div>

        </div>
      </form>
      <BR>
    </div>
  </section>

  <!-- footer section -->

  <section class="footer-section" style="background: #361a4a !important;" >
  <div class="">
    <div class="col-md-12">
    <p style="    text-align: center;
    font-size: 9px;
    color: #fff;
    padding: 15px;
    line-height: 1.5;">©️ 2022 THALYA
    THIS SITE IS NOT A PART OF THE FACEBOOK WEBSITE OR FACEBOOK INC.
    ADDITIONALLY, THIS SITE IS NOT ENDORSED BY FACEBOOK IN ANY WAY.
    FACEBOOK IS A TRADEMARK OF FACEBOOK, INC.</p>
    </div>
  </div>
</section> 


  <section class="fixed-mobile-button" style="background: #E31875;">
    <a href="#form1" class="text-center black-btn  button-cta">
      اطلب الآن 
      <span>
        التوصيل إلى جميع أنحاء المغرب
      </span>
    </a>
  </section>

 


 




<script src="static/js/lib/jquery-3.0.0.min.js"></script>
<script src="static/js/lib/owl.carousel.min.js" type="text/javascript"></script>

<script src="static/js/scripts.js" type="text/javascript"></script>

<script src="static/js/lib/jquery.validate.js" type="text/javascript"></script>




<script type="text/javascript">

   
$(document).ready(function(){
 

 
  $("#form1").validate({
    // Specify validation rules
    rules: {
      // The key name on the left side is the name attribute
      // of an input field. Validation rules are defined
      // on the right side
      first_name: "required",
      city: "required",
      phone:{
       required: true,
      number: true
      },
      address:"required"
    },
    // Specify validation error messages
    messages: {
      first_name: "Veuillez insérer votre nom et prénom",
      city: "Veuillez insérer votre ville",
      tel: 'Veuillez insérer un numéro de téléphone',
      address:"Veuillez insérer votre adresse de livraison"
    },
    // Make sure the form is submitted to the destination defined
    // in the "action" attribute of the form when valid
    submitHandler: function(form) {
      form.submit();
    }

  });
 
  
// owl slider 
    $('.carousel-testimonials').owlCarousel({
        items: 3,
        itemsDesktop: [1023,3],
        itemsTablet: [959,2],
        itemsMobile : [768,2],
        singleItem : false,
        autoPlay: 7000,
        paginationSpeed: 1600,
        navigation: false,
        pagination: true,
        responsive: true,
        paginationNumbers: false,
        stopOnHover: true
    });
 
 
    $('.carousel-ingred, .carousel-ingred-2').owlCarousel({
        items: 3,
        itemsDesktop: [1023,1],
        itemsTablet: [959,1],
        itemsMobile : [768,1],
        singleItem : false,
        autoPlay: 2000,
        paginationSpeed: 700,
        navigation: false,
        pagination: true,
        responsive: true,
        paginationNumbers: false,
        stopOnHover: true
    }); 

    
// end owl slider 

 $('#product').on('change', function(){
  changeTextPrice();
 })

 function changeTextPrice() {
  var selected = $('#product').prop('selectedIndex');
  if(selected== 0){
    $('#price').html(' 279 درهم  ( توصيل مجاني )')
  }
  else if(selected== 1){$('#price').html('279 درهم  ( توصيل مجاني )')}
  else if(selected== 2){$('#price').html('329 درهم  ( توصيل مجاني )')}

  else if(selected== 3){$('#price').html('279 درهم  ( توصيل مجاني )')}
  else{$('#price').html(' 279 درهم  ( توصيل مجاني )')}
 }
 
 $(".gotoform").click(function(e) {
    // Prevent a page reload when a link is pressed

    e.preventDefault();

    var indexProduit = $(this).data('product');

    $('#product option').eq(indexProduit).prop('selected', true);

    changeTextPrice();

    $('html,body').animate({
        scrollTop: $("#form1").offset().top
    }, 'slow'); 




});
$('#pays').on('change', function(){
  var selected = $(this).prop('selectedIndex');
  if(selected== 1){
    $('#msgRedirection').fadeIn();
    setTimeout(function(){
      window.location.replace("https://kwancosmetics.com/products/cure-soin-profond-kwan");
    }, 2000);

  }

 })

 $('#toggle').click(function() {
   $(this).toggleClass('active');
   $('#overlay').toggleClass('open');
  });



});
/* ######### accordion benifits ########### */
function accordion(id){
  $('#collspan-'+id).slideToggle();
}

/* ######### sticky menu 1 ########### */
let timeout = 0
let previousScrollY = 0
function scan() {
  const sticky = document.querySelector('header')
  let scrollY = window.scrollY
  let scrollingDirection = scrollY - previousScrollY
  if (scrollY > sticky.offsetHeight) {
    if (scrollingDirection < 0) {
      sticky.setAttribute('data-visible', 'sticky');
      $(".sticky").css({"top":"43px"});
    } else if (scrollingDirection > 0) {
      sticky.setAttribute('data-visible', 'false');
      $(".sticky").css({"top":"0px"});
    }
  } else {
    sticky.setAttribute('data-visible', 'true')
  }
  previousScrollY = scrollY
}
window.onscroll = function() {
  clearTimeout();
  timeout = setTimeout(scan, 10)
}

/* ######### sticky menu 2 ########### */
var div_top = $('.menu').offset().top;

$(window).scroll(function() {
    var window_top = $(window).scrollTop() - 0;
    if (window_top > div_top) {
        if (!$('.menu').is('.sticky')) {
            $('.menu').addClass('sticky');
        }
    } else {
        $('.menu').removeClass('sticky');
    }
});
</script>
</body>

</html>
